<!DOCTYPE html>
<html lang="en">
<head>    
    <title>Document</title>
</head>
<body>    
    <table>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><?php echo e($email); ?></td>
        </tr>        
        <tr>
            <td>Name</td>
            <td>:</td>            
            <td><?php echo e(name); ?></td>           
        </tr>
    </table>
    <a href="<?php echo e($url); ?>">Reset Password</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravue-nblc\resources\views/emailResetPassword.blade.php ENDPATH**/ ?>