<!DOCTYPE html>
<html lang="en">
<head>    
    <title>Document</title>
</head>
<body>    
    <?php echo $email_body; ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravue-nblc\resources\views/emailBlast.blade.php ENDPATH**/ ?>