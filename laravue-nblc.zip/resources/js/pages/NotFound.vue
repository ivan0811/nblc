<template>
    <div>
        <div class="d-flex">
            404
        </div>
    </div>
</template>
<script>
export default {
    
}
</script>