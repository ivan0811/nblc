<template>
     <v-main class="bg-admin">
      <v-container
        class="py-8 px-6"
        fluid        
      >
       
      </v-container>
    </v-main>
</template>
<script>
export default {
    
}
</script>