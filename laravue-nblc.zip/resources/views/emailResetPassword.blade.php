<!DOCTYPE html>
<html lang="en">
<head>    
    <title>Document</title>
</head>
<body>    
    <table>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td>{{$email}}</td>
        </tr>        
        <tr>
            <td>Name</td>
            <td>:</td>            
            <td>{{name}}</td>           
        </tr>
    </table>
    <a href="{{$url}}">Reset Password</a>
</body>
</html>