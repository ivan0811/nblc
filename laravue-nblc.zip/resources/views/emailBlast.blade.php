<!DOCTYPE html>
<html lang="en">
<head>    
    <title>Document</title>
</head>
<body>    
    {!! $email_body !!}
</body>
</html>